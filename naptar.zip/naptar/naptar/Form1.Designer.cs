﻿namespace naptar
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cimke = new System.Windows.Forms.Label();
            this.szinezes = new System.Windows.Forms.Button();
            this.ujablak = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cimke
            // 
            this.cimke.AutoSize = true;
            this.cimke.Location = new System.Drawing.Point(110, 21);
            this.cimke.Name = "cimke";
            this.cimke.Size = new System.Drawing.Size(70, 13);
            this.cimke.TabIndex = 0;
            this.cimke.Text = "Ez egy cimke";
            // 
            // szinezes
            // 
            this.szinezes.Location = new System.Drawing.Point(105, 61);
            this.szinezes.Name = "szinezes";
            this.szinezes.Size = new System.Drawing.Size(75, 23);
            this.szinezes.TabIndex = 1;
            this.szinezes.Text = "Színezés";
            this.szinezes.UseVisualStyleBackColor = true;
            this.szinezes.Click += new System.EventHandler(this.szinezes_Click);
            // 
            // ujablak
            // 
            this.ujablak.Location = new System.Drawing.Point(105, 107);
            this.ujablak.Name = "ujablak";
            this.ujablak.Size = new System.Drawing.Size(75, 23);
            this.ujablak.TabIndex = 2;
            this.ujablak.Text = "Új ablak";
            this.ujablak.UseVisualStyleBackColor = true;
            this.ujablak.Click += new System.EventHandler(this.ujablak_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.ujablak);
            this.Controls.Add(this.szinezes);
            this.Controls.Add(this.cimke);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vezerlő";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label cimke;
        private System.Windows.Forms.Button szinezes;
        private System.Windows.Forms.Button ujablak;
    }
}

