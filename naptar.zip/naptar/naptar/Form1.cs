﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace naptar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            void InitializeComponent()
                 
            {
                this.cimke = new System.Windows.Forms.Label();
                this.szinezes = new System.Windows.Forms.Button();
                this.ujablak = new System.Windows.Forms.Button();
                this.SuspendLayout();

                this.cimke.Location = new System.Drawing.Point(95, 68);
                this.cimke.AutoSize = true;
                this.cimke.Name = "cimke";
                this.cimke.Size = new System.Drawing.Size(72, 13);
                this.cimke.TabIndex = 0;
                this.cimke.Text = "egy cimket olvasol";
            }
                
                
                
        }

        private void Form1_Load(object sender, EventArgs e)
        {
             Button bezar = new Button();
            bezar.Text = "Bezárás";     
            bezar.Location = new System.Drawing.Point(98, 220);
            bezar.Click += new EventHandler(bezar_Click);
            this.Controls.Add(bezar);
        }

        private void bezar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void szinezes_Click(object sender, EventArgs e)
        {
            cimke.ForeColor = Color.Coral;
            this.CenterToScreen();
            this.BackColor = Color.CornflowerBlue;
        }

        private void ujablak_Click(object sender, EventArgs e)
        {
            Form ujform = new Form();
            ujform.BackColor = Color.DarkOrange;
            ujform.Text = "ez egy uj ablak";
            Label cimke = new Label();
            cimke.Text = "ez egy uj cimke";
            cimke.Location = new Point (90,50);
            ujform.Controls.Add(cimke);
            ujform.Show();
        }
    }
}
