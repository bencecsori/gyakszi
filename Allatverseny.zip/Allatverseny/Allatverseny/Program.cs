﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security;
using System.Text;
using System.Threading.Tasks;

namespace Allatverseny
{
    class Allat
    {
        public string Nev { get; private set; }
        public int SzuletesiEv { get; private set; }
        public int RajtSzam { get; private set; }

        public int Szepsegpont { get; private set; }

        public int ViselkedesiPont { get; private set; }
        public static int AktualisEv { get; set; }

        public static int Korhatar { get; set; }

        public Allat(string nev, int szuletesiEv, int rajtSzam)
        {
            Nev = nev;
            SzuletesiEv = szuletesiEv;
            RajtSzam = rajtSzam;
        }

        public int Kor()
        {
            return AktualisEv - SzuletesiEv;
        }

        public virtual int Pontszam()
        {
            if (Kor() < Korhatar)
            {
                return ViselkedesiPont * Kor() + Szepsegpont * (Korhatar - Kor());
            }
            return 0;
        }

        public void Pontozzak(int szepsegPont, int viselkedesiPont)
        {
            this.Szepsegpont = szepsegPont;
            this.ViselkedesiPont = viselkedesiPont;
        }

        public override string ToString()
        {
            return RajtSzam + ". " + Nev + "nevű" + this.GetType().Name.ToLower()
                + "pontszama: " + Pontszam() + " pont";
        }


        class Kutya : Allat
        {
            public int GazdaViszonyPont { get; private set; }
            public bool KapottViszonyPontot { get; private set; }

            public Kutya(string nev, int rajtSzam, int szulEv) :
                base(nev, rajtSzam, szulEv)
            {

            }

            public void ViszonyPontozas(int gazdaViszonyPont)
            {
                this.GazdaViszonyPont = gazdaViszonyPont;
                KapottViszonyPontot = true;
            }

            public override int Pontszam()
            {
                int pont = 0;
                if (KapottViszonyPontot)
                {
                    pont = base.Pontszam() + GazdaViszonyPont;

                }
                return pont;

            }
        }

        class Macska : Allat
        {
            public bool VanMacskaSzallitoDoboz { get; set; }

            public Macska(string nev, int rajtSzam, int szulEv, bool vanMacskaSzallitoDoboz) :
                base(nev, rajtSzam, szulEv)
            {
                this.VanMacskaSzallitoDoboz = vanMacskaSzallitoDoboz;
            }

            public override int Pontszam()
            {
                if (VanMacskaSzallitoDoboz)
                { return base.Pontszam(); }
                return 0;

            }

        }

        class Vezerles
        {
            private List<Allat> allatok = new List<Allat>();

            public void Start() {
                Allat.AktualisEv = 2015;
                Allat.Korhatar = 10;

                Proba();

                Regisztracio();

                Kiiratas("A regisztralt versenyzok");
                Verseny();
                Kiiratas("A verseny eredmenye");
            }

            private void Kiiratas(string v)
            {
                foreach (Allat allat in allatok)
                {
                    Console.WriteLine("Az allat neve: " + allat.Nev + "pontszama: " + allat.Pontszam());
                }
            }

            private void Proba()
            {
                Allat allat1, allat2;

                string nev1 = "Pamacs", nev2 = "Bolhazsak";
                int szulEv1 = 2010, szulev2 = 2011;
                bool vanDoboz = true;
                int rajtSzam = 1;

                int szepsegPont = 5;
                int viselkdesiPont = 4;
                int viszonyPont = 6;

                allat1 = new Kutya(nev1, rajtSzam, szulEv1);
                rajtSzam++;

                allat2 = new Macska(nev1, rajtSzam, szulEv1, vanDoboz);

                Console.WriteLine("A regisztralt allatok");
                Console.WriteLine(allat1);
                Console.WriteLine(allat2);


                allat1.Pontozzak(szepsegPont, viselkdesiPont);
                allat2.Pontozzak(szepsegPont, viselkdesiPont);

                Console.WriteLine("A verseny eredmenye");
                Console.WriteLine(allat1);
                Console.WriteLine(allat2);
            }

            private void Regisztracio()
            {
                StreamReader beolvas = new StreamReader("allatok.txt");

                string fajta, nev;
                int rajtSzam = 1, szulEv;
                bool vanDoboz;

                while (beolvas.EndOfStream)
                {
                    fajta = beolvas.ReadLine();
                    nev = beolvas.ReadLine();
                    szulEv = int.Parse(beolvas.ReadLine());

                    if (fajta == "macska")
                    {
                        vanDoboz = bool.Parse(beolvas.ReadLine());
                        allatok.Add(new Macska(nev, rajtSzam, szulEv, vanDoboz));
                    }
                    else
                    {
                        vanDoboz = bool.Parse(beolvas.ReadLine());
                        allatok.Add(new Kutya(nev, rajtSzam, szulEv));
                    }
                    rajtSzam++;

                }
                beolvas.Close();
            }

            private void Verseny()
            {
                Random random = new Random();
                int hatar = 11;
                foreach (Allat item in allatok)
                {
                    if (item is Kutya)
                    {
                        (item as Kutya).ViszonyPontozas(random.Next(hatar));    
                    }
                    item.Pontozzak(random.Next(hatar), random.Next(hatar));
                }
            }
        }

        

        internal class Program
        {
            static void Main(string[] args)
            {
                Console.ReadKey();
            }
        }
    }
}
