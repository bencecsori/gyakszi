﻿namespace Allatverseny
{
    internal class ProgramBase
    {
    }
}