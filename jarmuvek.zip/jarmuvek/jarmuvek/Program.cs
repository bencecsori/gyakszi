﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jarmuvek
{

    abstract class Jarmu
    {

        public string Azonosito { get; private set; }
        public string Rendszam { get; set; }
        public int GyartasiEv { get; private set; }
        public double Fogyasztas { get; set; }

        public double FutottKm { get; private set; }
        public int AktualisKoltseg { get; private set; }
        public bool Szabad { get; private set; }

        public static int AktialisEv { get; set; }
        public static int AlapDij { get; set; }
        public static double HaszonKulcs { get; set; }

        public Jarmu(string azonosito, string rendszam, int gyartasiEv, double fogyasztas)
        {
            this.Azonosito = azonosito;
            this.Rendszam = rendszam;
            this.GyartasiEv = gyartasiEv;
            this.Fogyasztas = fogyasztas;
            this.Szabad = true;
        }
        public int Kor()
        {
            return AktialisEv - GyartasiEv;
        }

        public bool Fuvaroz(double ut, int benzinAr)
        {
            if (Szabad)
            {
                FutottKm += ut;
                AktualisKoltseg = (int)(benzinAr * ut * Fogyasztas / 100);
                Szabad = false;
                return true;
            }
            return false;
        }

        public virtual int BerletDij()
        {
            return (int)(AlapDij + AktualisKoltseg * HaszonKulcs / 100);
        }

        public void vegzett()
        {
            Szabad = true;
        }

        public override string ToString()
        {
            string nev = this.GetType().Name.ToLower();
            return string.Format("\nA {0-10}\n\tazpnpsotoja {1-3}" +
                "\n\trendszama: {2,-8}" +
                "\n\tkora: {3,3} ev" +
                "\n\tfogyasztasa: {4,3:00.0 liter /100km" +
                "\n\ta km-ora allasa: {5,8:00.00} km",
                nev, Azonosito, Rendszam, Kor(), Fogyasztas, FutottKm);
        }

        class Busz : Jarmu
        {
            public int FeroHely { get; private set; }
            public static double Szorzo { get; set; }

            public Busz(string azonosito, string rendszam, int gyartasiEv, int ferohely, double fogyasztas) :
                base(azonosito, rendszam, gyartasiEv, fogyasztas)
            {
                this.FeroHely = ferohely;
            }

            public override int BerletDij()
            {
                return (int)(base.BerletDij() + FeroHely * Szorzo);
            }
            public override string ToString()
            {
                return base.ToString() + "\n\tFerohely szama: " + FeroHely;
            }
        }

        class TeherAuto : Jarmu
        {
            public double teherBiras { get; private set; }
            public static double Szorzo { get; set; }
            public TeherAuto(string azonosito, string rendszam, int gyartasiEv, double fogyasztas, double teherBiras) : base(azonosito, rendszam, gyartasiEv, fogyasztas)
            {
                this.teherBiras = teherBiras;
            }

            public override int BerletDij()
            {
                return (int)(base.BerletDij() + teherBiras * Szorzo);
            }
            public override string ToString()
            {
                return base.ToString() + "\n\tteherbiras: " + teherBiras + "tonna";
            }
        }
        class vezerles
        {
            private List<Jarmu> jarmuvek = new List<Jarmu>();
            private string BUSZ = "busz";
            private string TEHER_AUTO = "TeherAuto";

            public void indit()
            {
                StatikusBeallitas();
                Adatbevitel();
                Kiir("A regisztralt jarmuvek: ");
                Mukodtet();
                AtlagKor();
                LegtobbKilometer();
                Rendez();

            }
            private void StatikusBeallitas()
            {
                Jarmu.AktialisEv = 2015;
                Jarmu.AlapDij = 1000;
                Jarmu.HaszonKulcs = 10;

                Busz.Szorzo = 15;
                TeherAuto.Szorzo = 8.5;
            }

            private void Adatbevitel()
            {
                string tipus, rendszam, azonosito;
                int gyartEv, ferohely;
                double fogyasztas, teherbiras;

                StreamReader beolvas = new StreamReader("jarmuvek.txt");

                int sorszam = 1;

                while (!beolvas.EndOfStream)
                {
                    tipus = beolvas.ReadLine();
                    Console.WriteLine(tipus);
                    rendszam = beolvas.ReadLine();
                    Console.WriteLine(rendszam);
                    gyartEv = int.Parse(beolvas.ReadLine());
                    fogyasztas = double.Parse(beolvas.ReadLine());
                    azonosito = tipus.Substring(0, 1).ToUpper() + sorszam;

                    if (tipus == BUSZ)
                    {
                        ferohely = int.Parse(beolvas.ReadLine());
                        jarmuvek.Add(new Busz(azonosito, rendszam, gyartEv, ferohely, fogyasztas));

                    }
                    else if (tipus == TEHER_AUTO)
                    {
                        teherbiras = double.Parse(beolvas.ReadLine());
                        jarmuvek.Add(new TeherAuto(azonosito, rendszam, gyartEv, fogyasztas, teherbiras));

                    }
                    sorszam++;

                }
                beolvas.Close();
            }

            private void Kiir(string cim)
            {
                Console.WriteLine(cim);
                foreach (Jarmu item in jarmuvek)
                {
                    Console.WriteLine(item);
                }
            }

            private void Mukodtet()
            {
                int osszKoltseg = 0, osszBevetel = 0;

                Random random = new Random();
                int alsoBenzinAr = 400, felsoBenzinAr = 420;
                double utMax = 300;
                int mukodesHatar = 200;
                int jarmuIndex;

                Jarmu jarmu;
                int fuvarszam = 0;
                for (int i = 0; i < (int)random.Next(mukodesHatar); i++)
                {
                    jarmuIndex = random.Next(jarmuvek.Count());
                    jarmu = jarmuvek[jarmuIndex];
                    if (jarmu.Fuvaroz(random.NextDouble() * utMax, random.Next(alsoBenzinAr, felsoBenzinAr))) ;
                    fuvarszam++;
                    Console.WriteLine("rendzama: " + jarmu.Rendszam +
                    "\nkoltseg: " + jarmu.AktualisKoltseg + " bevetel: " + jarmu.BerletDij() + "ft");
                    osszBevetel += jarmu.BerletDij();
                    osszKoltseg += jarmu.AktualisKoltseg;
                }

                Console.WriteLine("\n\n teljes koltseg:" + osszKoltseg + "ft" + "\n\nbevetele: " + osszBevetel +" ft"+ "\n\nhaszon: "+ (osszBevetel -osszKoltseg )+ " ft");
                Console.WriteLine("\n a fuvarok szama " + fuvarszam);

            }

            private void AtlagKor()
            {
                double osszkor = 0;
                int darab = 0;
                foreach(Jarmu item in jarmuvek)
                {
                    osszkor += item.Kor();
                    darab++;
                }
                if (darab > 0 ) {
                    Console.WriteLine("\n Atlagkora: " + osszkor / darab + "ev");

                }

                else
                {
                    Console.WriteLine("null");
                }
            }

            private void LegtobbKilometer()
            {
                double max = jarmuvek[0].FutottKm;
                foreach(Jarmu item in jarmuvek)
                {
                    if(item.FutottKm > max)
                    {
                        max = item.FutottKm;
                    }
                }

                Console.WriteLine("\n a legtobbet futott jarmu  kmel: " + max);
                foreach(Jarmu item in jarmuvek)
                {
                    if(item.FutottKm == max)
                    {
                        Console.WriteLine(item.Rendszam);
                    }
                }
            }
            private void Rendez()
            {
                Jarmu temp;
                for (int i = 0; (i < jarmuvek.Count - 1); i++) {
                    for (int j = i + 1; (j < jarmuvek.Count); j++) {
                        if (jarmuvek[i].Fogyasztas > jarmuvek[j].Fogyasztas)
                        {
                            temp = jarmuvek[i];
                            jarmuvek[i] = jarmuvek[j];
                            jarmuvek[j] = temp;
                        }
                    }
                }
                Console.WriteLine("Fogyasztras szerint:");
                foreach(Jarmu item in jarmuvek)
                    Console.WriteLine("{0,-10} {1:00.0} liter / 100km"+ item.Rendszam, item.Fogyasztas);
            }


        }






        internal class Program
        {
            static void Main(string[] args)
            {
            }
        }
    }
}
