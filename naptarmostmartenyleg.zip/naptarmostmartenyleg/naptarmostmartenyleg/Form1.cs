﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace naptarmostmartenyleg
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private DateTime ma = DateTime.Now;
        private DateTime szuldatum;
        private DateTime valasztottDatum;
        private void button1_Click(object sender, EventArgs e)
        {



        }

        private void Form1_Load(object sender, EventArgs e)
        {
            lbldatum.Text = ma.ToString("f");
            gratulacio.Text = "";
            valasztottDatum = dateTimePicker1.Value;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            valasztottDatum = dateTimePicker1.Value;
            textBoxnapsorszam.Text = valasztottDatum.DayOfYear.ToString();
        }

        private void maskedTextszuldatum_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            szuldatum = DateTime.Parse(maskedTextszuldatum.Text);
            if (szuldatum.Month == ma.Month && szuldatum.Day == ma.Day)
            {
                gratulacio.Text = "isten eltessen";

            }
            else
            {
                gratulacio.Text = "Boldog nem szulinapot";
            }

        }

        private void btnkiir_Click(object sender, EventArgs e)
        {
            textBoxevszam.Text = (ma.Year - szuldatum.Year).ToString();
            textBoxnap.Text=szuldatum.DayOfWeek.ToString();
            textBoxnapsorszam.Text = valasztottDatum.DayOfYear.ToString();
        }

        private void gratulacio_Click(object sender, EventArgs e)
        {

        }
        private void Gratulacio()
        {
            try
            {
                if (!maskedTextszuldatum.MaskFull) throw new Exception();
                else
                {
                    szuldatum = DateTime.Parse(maskedTextszuldatum.Text);
                }
                if (szuldatum > ma) throw new Exception();
                if (szuldatum.Month == ma.Month && szuldatum.Day == ma.Day)
                {
                    gratulacio.Text = "isten eltessen";
                }
                else
                {
                    gratulacio.Text = "boldog hetkoznapot";
                }

            }
            catch (Exception)
            {
                MessageBox.Show("hibas datum", "hiba");
                maskedTextszuldatum.Focus();
            }

            
            
        } 
        private void maskedSzuldatum_Leave(object sender, EventArgs e)
        {
            Gratulacio();
        }

        private void textBoxkesobbidatum_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxnapsorszam_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxevszam_TextChanged(object sender, EventArgs e)
        {

        }

        private void btntorol_Click(object sender, EventArgs e)
        {
            foreach (var item in this.Controls)
            {
                if (item is TextBox) ((TextBox)item).Clear();

                gratulacio.Text = "";
                maskedTextszuldatum.Clear();
                

            }
        }

        private void btnbezar_Click(object sender, EventArgs e)
        {
            DialogResult valasz = MessageBox.Show("Biztosan kilep?","megerosites",MessageBoxButtons.YesNo);
            if (valasz == DialogResult.Yes) this.Close();
                
        }
    }
}
