﻿namespace naptarmostmartenyleg
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gratulacio = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbldatum = new System.Windows.Forms.Label();
            this.maskedTextszuldatum = new System.Windows.Forms.MaskedTextBox();
            this.textBoxevszam = new System.Windows.Forms.TextBox();
            this.textBoxkesobbidatum = new System.Windows.Forms.TextBox();
            this.textBoxnapsorszam = new System.Windows.Forms.TextBox();
            this.textBoxnapszam = new System.Windows.Forms.TextBox();
            this.textBoxnap = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnkiir = new System.Windows.Forms.Button();
            this.btnbezar = new System.Windows.Forms.Button();
            this.btntorol = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pontos datum es ido";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "szuletesi datum";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(32, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "ennyi eves vagy";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(254, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "ilyen napon szulettel";
            // 
            // gratulacio
            // 
            this.gratulacio.AutoSize = true;
            this.gratulacio.Location = new System.Drawing.Point(195, 210);
            this.gratulacio.Name = "gratulacio";
            this.gratulacio.Size = new System.Drawing.Size(35, 13);
            this.gratulacio.TabIndex = 5;
            this.gratulacio.Text = "label5";
            this.gratulacio.Click += new System.EventHandler(this.gratulacio_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(32, 285);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "tetszoleges datum";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(346, 285);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 7;
            this.label7.Text = "ev ennyiedik napja";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(346, 334);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 13);
            this.label8.TabIndex = 8;
            this.label8.Text = "nappal kesobbi datum";
            // 
            // lbldatum
            // 
            this.lbldatum.AutoSize = true;
            this.lbldatum.Location = new System.Drawing.Point(168, 29);
            this.lbldatum.Name = "lbldatum";
            this.lbldatum.Size = new System.Drawing.Size(30, 13);
            this.lbldatum.TabIndex = 9;
            this.lbldatum.Text = "asfaf";
            // 
            // maskedTextszuldatum
            // 
            this.maskedTextszuldatum.Location = new System.Drawing.Point(117, 83);
            this.maskedTextszuldatum.Name = "maskedTextszuldatum";
            this.maskedTextszuldatum.Size = new System.Drawing.Size(100, 20);
            this.maskedTextszuldatum.TabIndex = 10;
            this.maskedTextszuldatum.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.maskedTextszuldatum_MaskInputRejected);
            // 
            // textBoxevszam
            // 
            this.textBoxevszam.Location = new System.Drawing.Point(134, 131);
            this.textBoxevszam.Name = "textBoxevszam";
            this.textBoxevszam.Size = new System.Drawing.Size(64, 20);
            this.textBoxevszam.TabIndex = 11;
            this.textBoxevszam.TextChanged += new System.EventHandler(this.textBoxevszam_TextChanged);
            // 
            // textBoxkesobbidatum
            // 
            this.textBoxkesobbidatum.Location = new System.Drawing.Point(365, 350);
            this.textBoxkesobbidatum.Name = "textBoxkesobbidatum";
            this.textBoxkesobbidatum.Size = new System.Drawing.Size(64, 20);
            this.textBoxkesobbidatum.TabIndex = 12;
            this.textBoxkesobbidatum.TextChanged += new System.EventHandler(this.textBoxkesobbidatum_TextChanged);
            // 
            // textBoxnapsorszam
            // 
            this.textBoxnapsorszam.Location = new System.Drawing.Point(362, 311);
            this.textBoxnapsorszam.Name = "textBoxnapsorszam";
            this.textBoxnapsorszam.Size = new System.Drawing.Size(64, 20);
            this.textBoxnapsorszam.TabIndex = 13;
            this.textBoxnapsorszam.TextChanged += new System.EventHandler(this.textBoxnapsorszam_TextChanged);
            // 
            // textBoxnapszam
            // 
            this.textBoxnapszam.Location = new System.Drawing.Point(208, 285);
            this.textBoxnapszam.Name = "textBoxnapszam";
            this.textBoxnapszam.Size = new System.Drawing.Size(64, 20);
            this.textBoxnapszam.TabIndex = 14;
            // 
            // textBoxnap
            // 
            this.textBoxnap.Location = new System.Drawing.Point(362, 141);
            this.textBoxnap.Name = "textBoxnap";
            this.textBoxnap.Size = new System.Drawing.Size(64, 20);
            this.textBoxnap.TabIndex = 15;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(35, 334);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(237, 20);
            this.dateTimePicker1.TabIndex = 16;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // btnkiir
            // 
            this.btnkiir.Location = new System.Drawing.Point(55, 386);
            this.btnkiir.Name = "btnkiir";
            this.btnkiir.Size = new System.Drawing.Size(80, 23);
            this.btnkiir.TabIndex = 17;
            this.btnkiir.Text = "kiir";
            this.btnkiir.UseVisualStyleBackColor = true;
            this.btnkiir.Click += new System.EventHandler(this.btnkiir_Click);
            // 
            // btnbezar
            // 
            this.btnbezar.Location = new System.Drawing.Point(349, 386);
            this.btnbezar.Name = "btnbezar";
            this.btnbezar.Size = new System.Drawing.Size(80, 23);
            this.btnbezar.TabIndex = 18;
            this.btnbezar.Text = "bezar";
            this.btnbezar.UseVisualStyleBackColor = true;
            this.btnbezar.Click += new System.EventHandler(this.btnbezar_Click);
            // 
            // btntorol
            // 
            this.btntorol.Location = new System.Drawing.Point(208, 386);
            this.btntorol.Name = "btntorol";
            this.btntorol.Size = new System.Drawing.Size(80, 23);
            this.btntorol.TabIndex = 19;
            this.btntorol.Text = "torol";
            this.btntorol.UseVisualStyleBackColor = true;
            this.btntorol.Click += new System.EventHandler(this.btntorol_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btntorol);
            this.Controls.Add(this.btnbezar);
            this.Controls.Add(this.btnkiir);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBoxnap);
            this.Controls.Add(this.textBoxnapszam);
            this.Controls.Add(this.textBoxnapsorszam);
            this.Controls.Add(this.textBoxkesobbidatum);
            this.Controls.Add(this.textBoxevszam);
            this.Controls.Add(this.maskedTextszuldatum);
            this.Controls.Add(this.lbldatum);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.gratulacio);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label gratulacio;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbldatum;
        private System.Windows.Forms.MaskedTextBox maskedTextszuldatum;
        private System.Windows.Forms.TextBox textBoxevszam;
        private System.Windows.Forms.TextBox textBoxkesobbidatum;
        private System.Windows.Forms.TextBox textBoxnapsorszam;
        private System.Windows.Forms.TextBox textBoxnapszam;
        private System.Windows.Forms.TextBox textBoxnap;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btnkiir;
        private System.Windows.Forms.Button btnbezar;
        private System.Windows.Forms.Button btntorol;
    }
}

