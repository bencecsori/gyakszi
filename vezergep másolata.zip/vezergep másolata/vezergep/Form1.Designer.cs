﻿namespace vezergep
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.kezdoszoveg = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.benzinar = new System.Windows.Forms.TextBox();
            this.uthossz = new System.Windows.Forms.TextBox();
            this.frissites = new System.Windows.Forms.Button();
            this.eredmeny = new System.Windows.Forms.Label();
            this.benya = new System.Windows.Forms.Label();
            this.megtettut = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.bevTxt = new System.Windows.Forms.TextBox();
            this.koltTxt = new System.Windows.Forms.TextBox();
            this.haszTxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.osszead2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.frissites2 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Location = new System.Drawing.Point(-3, 3);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(805, 456);
            this.tabControl.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabPage1.BackgroundImage")));
            this.tabPage1.Controls.Add(this.kezdoszoveg);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(797, 430);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Kezdőlap";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // kezdoszoveg
            // 
            this.kezdoszoveg.AutoSize = true;
            this.kezdoszoveg.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.kezdoszoveg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.kezdoszoveg.Location = new System.Drawing.Point(195, 314);
            this.kezdoszoveg.MaximumSize = new System.Drawing.Size(1000, 1000);
            this.kezdoszoveg.Name = "kezdoszoveg";
            this.kezdoszoveg.Size = new System.Drawing.Size(426, 42);
            this.kezdoszoveg.TabIndex = 0;
            this.kezdoszoveg.Text = "Járműpark üzemeltetés";
            this.kezdoszoveg.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.tabPage2.Controls.Add(this.button3);
            this.tabPage2.Controls.Add(this.benzinar);
            this.tabPage2.Controls.Add(this.uthossz);
            this.tabPage2.Controls.Add(this.frissites);
            this.tabPage2.Controls.Add(this.eredmeny);
            this.tabPage2.Controls.Add(this.benya);
            this.tabPage2.Controls.Add(this.megtettut);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.listBox2);
            this.tabPage2.Controls.Add(this.listBox1);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(797, 430);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Buszok";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(580, 378);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(137, 35);
            this.button3.TabIndex = 14;
            this.button3.Text = "szamol";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // benzinar
            // 
            this.benzinar.Location = new System.Drawing.Point(394, 333);
            this.benzinar.Name = "benzinar";
            this.benzinar.Size = new System.Drawing.Size(80, 20);
            this.benzinar.TabIndex = 13;
            this.benzinar.TextChanged += new System.EventHandler(this.benzinar_TextChanged);
            // 
            // uthossz
            // 
            this.uthossz.Location = new System.Drawing.Point(555, 333);
            this.uthossz.Name = "uthossz";
            this.uthossz.Size = new System.Drawing.Size(80, 20);
            this.uthossz.TabIndex = 12;
            this.uthossz.TextChanged += new System.EventHandler(this.uthossz_TextChanged);
            // 
            // frissites
            // 
            this.frissites.Location = new System.Drawing.Point(400, 378);
            this.frissites.Name = "frissites";
            this.frissites.Size = new System.Drawing.Size(146, 34);
            this.frissites.TabIndex = 11;
            this.frissites.Text = "frissites";
            this.frissites.UseVisualStyleBackColor = true;
            this.frissites.Click += new System.EventHandler(this.button3_Click);
            // 
            // eredmeny
            // 
            this.eredmeny.AutoSize = true;
            this.eredmeny.Location = new System.Drawing.Point(652, 329);
            this.eredmeny.Name = "eredmeny";
            this.eredmeny.Size = new System.Drawing.Size(97, 13);
            this.eredmeny.TabIndex = 10;
            this.eredmeny.Text = "Ennyibe fog kerulni";
            this.eredmeny.Click += new System.EventHandler(this.eredmeny_Click);
            // 
            // benya
            // 
            this.benya.AutoSize = true;
            this.benya.Location = new System.Drawing.Point(334, 336);
            this.benya.Name = "benya";
            this.benya.Size = new System.Drawing.Size(50, 13);
            this.benya.TabIndex = 6;
            this.benya.Text = "benzinár:";
            // 
            // megtettut
            // 
            this.megtettut.AutoSize = true;
            this.megtettut.Location = new System.Drawing.Point(480, 336);
            this.megtettut.Name = "megtettut";
            this.megtettut.Size = new System.Drawing.Size(57, 13);
            this.megtettut.TabIndex = 5;
            this.megtettut.Text = "megtett ut:";
            this.megtettut.Click += new System.EventHandler(this.label1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(290, 232);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(127, 33);
            this.button2.TabIndex = 3;
            this.button2.Text = "<-------";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(290, 79);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(127, 33);
            this.button1.TabIndex = 2;
            this.button1.Text = "-------->";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(465, 22);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(195, 290);
            this.listBox2.TabIndex = 1;
            this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(56, 22);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(179, 290);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.label4);
            this.tabPage3.Controls.Add(this.textBox2);
            this.tabPage3.Controls.Add(this.textBox1);
            this.tabPage3.Controls.Add(this.listBox4);
            this.tabPage3.Controls.Add(this.listBox3);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.frissites2);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.osszead2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(797, 430);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Teherautok";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Cyan;
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.label1);
            this.tabPage4.Controls.Add(this.haszTxt);
            this.tabPage4.Controls.Add(this.koltTxt);
            this.tabPage4.Controls.Add(this.bevTxt);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(797, 430);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Könyvelés";
            // 
            // bevTxt
            // 
            this.bevTxt.Location = new System.Drawing.Point(342, 62);
            this.bevTxt.Name = "bevTxt";
            this.bevTxt.ReadOnly = true;
            this.bevTxt.Size = new System.Drawing.Size(100, 20);
            this.bevTxt.TabIndex = 0;
            this.bevTxt.Text = "0";
            this.bevTxt.TextChanged += new System.EventHandler(this.bevTxt_TextChanged);
            // 
            // koltTxt
            // 
            this.koltTxt.Location = new System.Drawing.Point(342, 119);
            this.koltTxt.Name = "koltTxt";
            this.koltTxt.ReadOnly = true;
            this.koltTxt.Size = new System.Drawing.Size(100, 20);
            this.koltTxt.TabIndex = 1;
            this.koltTxt.Text = "0";
            // 
            // haszTxt
            // 
            this.haszTxt.Location = new System.Drawing.Point(342, 176);
            this.haszTxt.Name = "haszTxt";
            this.haszTxt.ReadOnly = true;
            this.haszTxt.Size = new System.Drawing.Size(100, 20);
            this.haszTxt.TabIndex = 2;
            this.haszTxt.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(335, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "bevetel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(339, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "kiadas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(339, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "haszon";
            // 
            // osszead2
            // 
            this.osszead2.Location = new System.Drawing.Point(569, 337);
            this.osszead2.Name = "osszead2";
            this.osszead2.Size = new System.Drawing.Size(144, 32);
            this.osszead2.TabIndex = 0;
            this.osszead2.Text = "osszead2";
            this.osszead2.UseVisualStyleBackColor = true;
            this.osszead2.Click += new System.EventHandler(this.osszead2_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(306, 68);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(144, 32);
            this.button5.TabIndex = 1;
            this.button5.Text = "------>";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // frissites2
            // 
            this.frissites2.Location = new System.Drawing.Point(359, 337);
            this.frissites2.Name = "frissites2";
            this.frissites2.Size = new System.Drawing.Size(144, 32);
            this.frissites2.TabIndex = 2;
            this.frissites2.Text = "frissit";
            this.frissites2.UseVisualStyleBackColor = true;
            this.frissites2.Click += new System.EventHandler(this.frissites2_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(306, 198);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(144, 32);
            this.button7.TabIndex = 3;
            this.button7.Text = "<------";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.Location = new System.Drawing.Point(521, 55);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(171, 225);
            this.listBox3.TabIndex = 4;
            // 
            // listBox4
            // 
            this.listBox4.FormattingEnabled = true;
            this.listBox4.Location = new System.Drawing.Point(68, 55);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(171, 225);
            this.listBox4.TabIndex = 5;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(571, 297);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 6;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(383, 297);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(120, 20);
            this.textBox2.TabIndex = 7;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(303, 304);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "benzinar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(518, 304);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "megtett ut";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(724, 282);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "ennyibe fog kerulni";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label kezdoszoveg;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Label benya;
        private System.Windows.Forms.Label megtettut;
        private System.Windows.Forms.Label eredmeny;
        private System.Windows.Forms.Button frissites;
        private System.Windows.Forms.TextBox benzinar;
        private System.Windows.Forms.TextBox uthossz;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox haszTxt;
        private System.Windows.Forms.TextBox koltTxt;
        private System.Windows.Forms.TextBox bevTxt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button osszead2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button frissites2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }
}

