﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace vezergep
{
    public partial class Form1 : Form
    {
        List<string> adatok = new List<string>();
        List<double> doubles = new List<double>();
        List<int> ints = new List<int>();

        double kolt;
        double hasz;

        public Form1()
        {
            InitializeComponent();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
         

            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                listBox2.Items.Add(listBox1.Items[listBox1.SelectedIndex]);
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox2.SelectedIndex != -1)
            {
                listBox1.Items.Add(listBox2.Items[listBox2.SelectedIndex]);
                listBox2.Items.RemoveAt(listBox2.SelectedIndex);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void eredmeny_Click(object sender, EventArgs e)
        {
         

            
            

            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            bevTxt.Text = (int.Parse(bevTxt.Text) + hasz).ToString();
            koltTxt.Text = (int.Parse(koltTxt.Text) + kolt).ToString();
            haszTxt.Text = (int.Parse(haszTxt.Text) + hasz - kolt).ToString();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            double osszeg = 0;
            double koltseg = 0;

            if (listBox2.Items.Count != 0 && benzinar.Text != "" && uthossz.Text != "")
            {
                for (int i = 0; i < listBox2.Items.Count; i++)
                {
                    for (int j = 0; j < adatok.Count; j++)
                    {
                        if (listBox2.Items[i].ToString() == adatok[j])
                        {
                            osszeg += doubles[j] * double.Parse(uthossz.Text) / 100 * double.Parse(benzinar.Text) + ints[j];
                            koltseg += doubles[j] * double.Parse(uthossz.Text) / 100 * double.Parse(benzinar.Text);
                            break;
                        }
                    }
                }
            }
            kolt = koltseg;
            hasz = osszeg;
            eredmeny.Text = osszeg.ToString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            StreamReader beolvas = new StreamReader("jarmuvek.txt");



            while (!beolvas.EndOfStream)
            {

                string[] strings = beolvas.ReadLine().Split(',');

                adatok.Add(strings[0]);
                doubles.Add(double.Parse(strings[1].Replace('.', ',')));
                ints.Add(Int32.Parse(strings[2]));



            }
            beolvas.Close();

            

           



            foreach (var item in adatok)
            {
                listBox1.Items.Add(item);
            }
        }

        private void bevTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (listBox3.SelectedIndex != -1)
            {
                listBox4.Items.Add(listBox1.Items[listBox3.SelectedIndex]);
                listBox3.Items.RemoveAt(listBox3.SelectedIndex);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (listBox4.SelectedIndex != -1)
            {
                listBox3.Items.Add(listBox4.Items[listBox4.SelectedIndex]);
                listBox4.Items.RemoveAt(listBox4.SelectedIndex);
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void benzinar_TextChanged(object sender, EventArgs e)
        {

        }

        private void uthossz_TextChanged(object sender, EventArgs e)
        {

        }

        private void osszead2_Click(object sender, EventArgs e)
        {
            double osszeg = 0;
            double koltseg = 0;

            if (listBox2.Items.Count != 0 && benzinar.Text != "" && uthossz.Text != "")
            {
                for (int i = 0; i < listBox2.Items.Count; i++)
                {
                    for (int j = 0; j < adatok.Count; j++)
                    {
                        if (listBox2.Items[i].ToString() == adatok[j])
                        {
                            osszeg += doubles[j] * double.Parse(uthossz.Text) / 100 * double.Parse(benzinar.Text);
                            koltseg += doubles[j] * double.Parse(uthossz.Text) / 100 * double.Parse(benzinar.Text);
                            break;
                        }
                    }
                }
            }
            kolt = koltseg;
            hasz = osszeg;
            eredmeny.Text = osszeg.ToString();
        }

        private void frissites2_Click(object sender, EventArgs e)
        {
            bevTxt.Text = (int.Parse(bevTxt.Text) + hasz).ToString();
            koltTxt.Text = (int.Parse(koltTxt.Text) + kolt).ToString();
            haszTxt.Text = (int.Parse(haszTxt.Text) + hasz - kolt).ToString();
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
}
