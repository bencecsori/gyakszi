﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace diakok
{
    public partial class Form1 : Form
    {
        List<Diak> diakok = new List<Diak>();
        List<CheckBox> CheckBoxok = new List<CheckBox>();
        public class Diak
        {
            public string nev;
            public string azonosito;
            public string egyetem;
            public int szulEv;


            public Diak(string nev, string azonosito, string egyetem,int szulEv)
            {
                this.nev = nev;
                this.azonosito = azonosito;
                this.egyetem = egyetem;
                this.szulEv = szulEv;
            }
        }
        public Form1()
        {
            InitializeComponent();
            openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
            openFileDialog1.FileName = "";
        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Gombbeallitas(false);
        }

        private void Gombbeallitas(bool aktiv)
        {
            adatbevitel.Enabled = !aktiv;
            kivalasztas.Enabled = aktiv;
        }

        private void AdatBevitel()
        {
            DialogResult eredmeny = openFileDialog1.ShowDialog();
            if (eredmeny == DialogResult.OK)
            {
                string fajlNev = openFileDialog1.FileName;
                try
                {
                    AdatBeolvasas();
                    FelrakDiakok();
                    Gombbeallitas(true);
                }

                catch (Exception)
                {
                    MessageBox.Show("Hiba volt a fajl beolvasasaban", "hiba");
                }
            }

        }


        private void AdatBeolvasas()
        {
            StreamReader beolvas = new StreamReader(openFileDialog1.FileName);
            string fajlNev;

            while (!beolvas.EndOfStream)
            {
                fajlNev = beolvas.ReadLine();
                Feldolgoz(fajlNev);
            }

        }
            private void Feldolgoz(string adat)
        {
            string[] adatok = adat.Split(';');
            Diak diak = new Diak(adatok[0], adatok[1], adatok[2], int.Parse(adatok[3]));
            diakok.Add(diak);
        }

        private void FelrakDiakok()
        {
            CheckBox chkBox;
            int kezdoX = 10;
            int kezdoY = 15;
            int chkYKoz = 40;
            for (int i = 0; i < diakok.Count; i++)
            {
                chkBox = new CheckBox();
                chkBox.AutoSize = true;
                chkBox.Location = new Point(kezdoX, kezdoY + i * chkYKoz);
                chkBox.Text = diakok[i].ToString();

                Diakok.Controls.Add(chkBox);
                CheckBoxok.Add(chkBox);
            }
        }

       

        private void Diakok_Paint(object sender, PaintEventArgs e)
        {

        }

        private void kivalasztas_Click(object sender, EventArgs e)
        {
            Kivalasztas();
        }

        private void Kivalasztas()
        {
            bool van = false;

            listBox2.Items.Clear();
            for (int i = 0; i < CheckBoxok.Count; i++)
            {
                if (CheckBoxok[i].Checked)
                {
                    listBox2.Items.Add(diakok[i]);
                    van = true;
                }
            }

            if (!van) { MessageBox.Show("Senkit nem valasztott", "hiba"); }
            else
            {
                MinKeres();
            }
        }

        private void MinKeres()
        {
            listBox1.Items.Clear();
            int min = (listBox2.Items[0] as Diak).szulEv;
            foreach (Diak diak in listBox1.Items)
            {
                if (diak.szulEv < min) min = diak.szulEv;
            }
            foreach (Diak diak in listBox1.Items)
            {
                if (diak.szulEv == min) listBox1.Items.Add(diak);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Diak diak = (Diak)listBox1.SelectedItem;
            if (diak != null) label3.Text = diak + ", Szuletesi eve:" +diak.szulEv;
        }
    }
}
