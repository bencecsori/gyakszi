﻿namespace uszoverseny
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rajtszam = new System.Windows.Forms.TextBox();
            this.orszag = new System.Windows.Forms.TextBox();
            this.idoeredmeny = new System.Windows.Forms.TextBox();
            this.gyoztesido = new System.Windows.Forms.TextBox();
            this.eletkor = new System.Windows.Forms.TextBox();
            this.gyoztes = new System.Windows.Forms.Button();
            this.adatbe = new System.Windows.Forms.Button();
            this.bezar = new System.Windows.Forms.Button();
            this.Emberek = new System.Windows.Forms.ListBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(345, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "200-m es pillango";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(155, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Résztvevők:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(502, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "rajtszám";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(502, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "ország";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(502, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "időeredmény";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(502, 209);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "életkor";
            // 
            // rajtszam
            // 
            this.rajtszam.Location = new System.Drawing.Point(585, 78);
            this.rajtszam.Name = "rajtszam";
            this.rajtszam.Size = new System.Drawing.Size(131, 20);
            this.rajtszam.TabIndex = 8;
            // 
            // orszag
            // 
            this.orszag.Location = new System.Drawing.Point(585, 119);
            this.orszag.Name = "orszag";
            this.orszag.Size = new System.Drawing.Size(131, 20);
            this.orszag.TabIndex = 9;
            this.orszag.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // idoeredmeny
            // 
            this.idoeredmeny.Location = new System.Drawing.Point(585, 162);
            this.idoeredmeny.Name = "idoeredmeny";
            this.idoeredmeny.Size = new System.Drawing.Size(131, 20);
            this.idoeredmeny.TabIndex = 10;
            // 
            // gyoztesido
            // 
            this.gyoztesido.Location = new System.Drawing.Point(585, 267);
            this.gyoztesido.Name = "gyoztesido";
            this.gyoztesido.Size = new System.Drawing.Size(131, 20);
            this.gyoztesido.TabIndex = 11;
            // 
            // eletkor
            // 
            this.eletkor.Location = new System.Drawing.Point(585, 209);
            this.eletkor.Name = "eletkor";
            this.eletkor.Size = new System.Drawing.Size(131, 20);
            this.eletkor.TabIndex = 12;
            // 
            // gyoztes
            // 
            this.gyoztes.Location = new System.Drawing.Point(505, 264);
            this.gyoztes.Name = "gyoztes";
            this.gyoztes.Size = new System.Drawing.Size(75, 23);
            this.gyoztes.TabIndex = 13;
            this.gyoztes.Text = "Győztes";
            this.gyoztes.UseVisualStyleBackColor = true;
            this.gyoztes.Click += new System.EventHandler(this.gyoztes_Click);
            // 
            // adatbe
            // 
            this.adatbe.Location = new System.Drawing.Point(158, 387);
            this.adatbe.Name = "adatbe";
            this.adatbe.Size = new System.Drawing.Size(172, 23);
            this.adatbe.TabIndex = 14;
            this.adatbe.Text = "Adatok beolvasasa";
            this.adatbe.UseVisualStyleBackColor = true;
            this.adatbe.Click += new System.EventHandler(this.adatbe_Click);
            // 
            // bezar
            // 
            this.bezar.Location = new System.Drawing.Point(547, 387);
            this.bezar.Name = "bezar";
            this.bezar.Size = new System.Drawing.Size(75, 23);
            this.bezar.TabIndex = 15;
            this.bezar.Text = "Bezárás";
            this.bezar.UseVisualStyleBackColor = true;
            // 
            // Emberek
            // 
            this.Emberek.FormattingEnabled = true;
            this.Emberek.Location = new System.Drawing.Point(158, 110);
            this.Emberek.Name = "Emberek";
            this.Emberek.Size = new System.Drawing.Size(172, 238);
            this.Emberek.TabIndex = 16;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(481, 304);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(235, 77);
            this.richTextBox1.TabIndex = 6;
            this.richTextBox1.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Emberek);
            this.Controls.Add(this.bezar);
            this.Controls.Add(this.adatbe);
            this.Controls.Add(this.gyoztes);
            this.Controls.Add(this.eletkor);
            this.Controls.Add(this.gyoztesido);
            this.Controls.Add(this.idoeredmeny);
            this.Controls.Add(this.orszag);
            this.Controls.Add(this.rajtszam);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox rajtszam;
        private System.Windows.Forms.TextBox orszag;
        private System.Windows.Forms.TextBox idoeredmeny;
        private System.Windows.Forms.TextBox gyoztesido;
        private System.Windows.Forms.TextBox eletkor;
        private System.Windows.Forms.Button gyoztes;
        private System.Windows.Forms.Button adatbe;
        private System.Windows.Forms.Button bezar;
        private System.Windows.Forms.ListBox Emberek;
        private System.Windows.Forms.RichTextBox richTextBox1;
    }
}

