﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace uszoverseny
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public class Versenyzo
        {

            public string rajtszam { get; private set; }
            public string nev { get; private set; }
            public string orszag { get; private set; }
            public DateTime szulDatum { get; private set; }
            public TimeSpan idoEredmeny { get; private set; }

            public Versenyzo(string rajtszam, string nev, string orszag, DateTime szulDatum, TimeSpan idoEredmeny)
            {
                this.rajtszam = rajtszam;
                this.nev = nev;
                this.orszag = orszag;
                this.szulDatum = szulDatum;
                this.idoEredmeny = idoEredmeny;
            }
            public override string ToString()
            {
                return nev;
            }
            private void AdatBeolvasas()
            {
                StreamReader beolvas = new StreamReader("uszok.txt");

                string adat = beolvas.ReadLine();
                while (adat != null)
                {
                    Feldolgoz(adat);
                    adat = beolvas.ReadLine();
                }
                beolvas.Close();

            }
            private void Feldolgoz(string adat)
            {
                string rajtszam, nev, orszag;
                DateTime szulDatum;
                TimeSpan idoEredmeny;
                Versenyzo versenyzo;
                string[] torldelt = adat.Split(';');


                rajtszam = torldelt[0];
                nev = torldelt[1];
                szulDatum = DateTime.Parse(torldelt[2]);
                orszag = torldelt[3];
                idoEredmeny = TimeSpan.Parse("0:" + torldelt[4]);
                versenyzo = new Versenyzo(rajtszam, nev, orszag, szulDatum, idoEredmeny);
                
                Emberek.Items.Add(versenyzo);


            }
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Emberek.Items.Clear();
        }

        private void adatbe_Click(object sender, EventArgs e)
        {
            Emberek.Items.Clear();
            AdatBeolvasas();
            adatbe.Enabled = false;
            gyoztes.Enabled = true;
        }

        private void Emberek_SelectedIndexChange(object sender, EventArgs e)
        {
            Versenyzo versenyzo = Emberek.SelectedItem as Versenyzo;
            rajtszam.Text = versenyzo.rajtszam;
            orszag.Text = versenyzo.orszag;
            idoeredmeny.Text = new DateTime(versenyzo.idoEredmeny.Ticks).ToString("mm:ss.ff");
            eletkor.Text = (DateTime.Now.Year - versenyzo.szulDatum.Year)+ "év";
        }

        private void gyoztes_Click(object sender, EventArgs e)
        {
            TimeSpan min = (Emberek.Items[0] as Versenyzo).idoEredmeny;
            foreach (var item in Emberek.Items)
            {
                if ((item as Versenyzo).idoEredmeny < min)
                {
                    min = (item as Versenyzo).idoEredmeny;
                }
            }
            gyoztesido.Text = new DateTime(min.Ticks).ToString("mm:ss:ff");
            richTextBox1.Clear();
            foreach (var item in Emberek.Items)
            {
                if((item as Versenyzo).idoEredmeny == min)
                {
                    richTextBox1.AppendText(item + "\n");
                }
            }
        }
    }
}
